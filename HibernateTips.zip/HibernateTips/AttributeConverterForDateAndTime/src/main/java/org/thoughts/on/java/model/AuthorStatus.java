package org.thoughts.on.java.model;

public enum AuthorStatus {

	PUBLISHED, SELF_PUBLISHED, NOT_PUBLISHED;
}
