INSERT INTO book (id, publishingdate, title, version) VALUES (1, '2017-04-04', 'Hibernate Tips', 0);
INSERT INTO book (id, publishingdate, title, version) VALUES (2, '2018-04-04', 'Another Book', 0);
INSERT INTO book (id, publishingdate, title, version) VALUES (3, '2019-04-04', 'My 3rd Book', 0);
