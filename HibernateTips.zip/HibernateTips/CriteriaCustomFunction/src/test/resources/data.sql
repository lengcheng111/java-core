INSERT INTO book (id, publishingdate, title, price, version) VALUES (1, '2008-05-08', 'Effective Java', 33.0, 0);
INSERT INTO book (id, publishingdate, title, price, version) VALUES (2, '2015-10-01', 'Java Persistence with Hibernate', 42.0, 0);
INSERT INTO book (id, publishingdate, title, price, version) VALUES (3, '2014-08-28', 'Java 8 in Action', 49.0, 0);
INSERT INTO book (id, publishingdate, title, price, version) VALUES (4, '2014-03-12', 'Continuous Enterprise Development in Java', 26.0, 0);
INSERT INTO book (id, publishingdate, title, price, version) VALUES (5, '2010-09-08', 'Enterprise JavaBeans 3.1', 45.0, 0);
INSERT INTO book (id, publishingdate, title, price, version) VALUES (6, '2014-04-29', 'Java Performance The Definitive Guide', 22.0, 0);