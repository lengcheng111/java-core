DROP SCHEMA IF EXISTS bookstore CASCADE;
DROP SEQUENCE hibernate_sequence