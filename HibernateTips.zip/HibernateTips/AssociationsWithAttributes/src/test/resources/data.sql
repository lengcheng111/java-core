INSERT INTO book (id, title, version) VALUES (1, 'Hibernate Tips', 0);

INSERT INTO publisher (id, name, version) VALUES (1, 'Thoughts on Java', 0);