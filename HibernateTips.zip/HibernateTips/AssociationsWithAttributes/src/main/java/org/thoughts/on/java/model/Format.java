package org.thoughts.on.java.model;

public enum Format {

	HARDCOVER, PAPERBACK, EBOOK;
}
